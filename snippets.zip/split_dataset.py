import os
import shutil
import random
import argparse

def is_image_file(filename):
    """
    Checks if the file is an image based on its extension.

    Args:
    filename (str): Name of the file to check.

    Returns:
    bool: True if the file is an image, False otherwise.
    """
    for ext in ['.jpg', '.jpeg', '.png']:
        if filename.lower().endswith(ext):
            return True
    return False

def split_dataset(base_path, train_ratio):
    """
    Splits the dataset into training and testing sets based on the specified train-test ratio.

    Args:
    base_path (str): Path to the directory containing images and XML files.
    train_ratio (float): Ratio of the dataset to be used as the training set (between 0 and 1).
    """
    train_path = os.path.join(base_path, 'train')
    test_path = os.path.join(base_path, 'test')

    # Create train and test directories
    os.makedirs(train_path, exist_ok=True)
    os.makedirs(test_path, exist_ok=True)

    # List and shuffle all image files
    all_image_files = [f for f in os.listdir(base_path) if is_image_file(f)]
    random.shuffle(all_image_files)

    # Calculate the number of files for the training set
    train_size = int(len(all_image_files) * train_ratio)

    # Move files to their respective directories
    for i, file in enumerate(all_image_files):
        file_no_ext = os.path.splitext(file)[0]
        corresponding_xml = file_no_ext + '.xml'
        
        if i < train_size:
            shutil.move(os.path.join(base_path, file), train_path)
            if os.path.exists(os.path.join(base_path, corresponding_xml)):
                shutil.move(os.path.join(base_path, corresponding_xml), train_path)
        else:
            shutil.move(os.path.join(base_path, file), test_path)
            if os.path.exists(os.path.join(base_path, corresponding_xml)):
                shutil.move(os.path.join(base_path, corresponding_xml), test_path)

    # Remove remaining files in base_path
    for file in os.listdir(base_path):
        file_path = os.path.join(base_path, file)
        if os.path.isfile(file_path):
            os.remove(file_path)

    print(f"Dataset split complete.\nTraining set path: {train_path}\nTesting set path: {test_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Split a dataset into training and testing sets based on a given ratio.")
    parser.add_argument('--input', type=str, required=True, help="Path to the directory containing images and XML files.")
    parser.add_argument('--train_ratio', type=float, required=True, help="Ratio of the dataset for training (between 0 and 1).")

    args = parser.parse_args()
    split_dataset(args.input, args.train_ratio)

